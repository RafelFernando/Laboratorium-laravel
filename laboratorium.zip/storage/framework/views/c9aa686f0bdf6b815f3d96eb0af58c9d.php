<?php $__env->startSection('judul', $data->nama_pemeriksaan); ?>
<?php $__env->startSection('konten'); ?>

<section class="hero is-success">
    <div class="hero-body">
        <div class="container">
            <h1 class="title"><?php echo e($data->nama_pemeriksaan); ?></h1>
            <h2 class="subtitle">Hasil Pemeriksaan: <?php echo e($data->kategori ? $data->kategori->nama_pasien : ''); ?></h2>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="columns is-centered">
            <div class="column is-three-quarters">
                <div class="card">
                    <header class="card-header">
                        <p class="card-header-title">
                            Detail Pemeriksaan
                        </p>
                    </header>
                    <div class="card-content">
						<div class="content">
                            <strong>Nama:</strong>
                            <p><?php echo e($data->kategori ? $data->kategori->nama_pasien : ''); ?></p>
                        </div>
						<div class="content">
                            <strong>Jenis Kelamin:</strong>
                            <p><?php echo e($data->kategori ? $data->kategori->jenis_kelamin : ''); ?></p>
                        </div>
						<div class="content">
                            <strong>Alamat:</strong>
                            <p><?php echo e($data->kategori ? $data->kategori->alamat : ''); ?></p>
                        </div>
                        <div class="content">
                            <strong>Hasil Pemeriksaan:</strong>
                            <p><?php echo e($data->hasil_pemeriksaan); ?></p>
                        </div>
                        <div class="content">
                            <strong>Gambar Hasil Pemeriksaan:</strong>
                            <?php if($data->gambar): ?>
                                <div class="image-container">
                                    <img src="<?php echo e(asset('storage/' . $data->gambar)); ?>" alt="Gambar Pemeriksaan">
                                </div>
                            <?php else: ?>
                                <p>Gambar tidak tersedia</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<style>
    .image-container {
        display: flex;
        justify-content: center;
    }
    .image-container img {
        max-width: 100%;
        height: auto;
    }
</style>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorium\resources\views/pemeriksaan/detail.blade.php ENDPATH**/ ?>