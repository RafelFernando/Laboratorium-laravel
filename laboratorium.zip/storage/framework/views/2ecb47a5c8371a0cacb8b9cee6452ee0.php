<?php $__env->startSection('judul', 'Pasien'); ?>
<?php $__env->startSection('konten'); ?>

<section class="hero is-success">
    <div class="hero-body">
        <p class="title">Daftar Pasien</p>
        <p class="subtitle">Laboratorium Pemeriksaan</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <table class="table is-fullwidth is-striped is-hoverable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Nama Pasien</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td>
                        <?php if($item->gambar): ?>
                        <figure class="image is-64x64">
                            <img src="<?php echo e(Storage::url($item->gambar)); ?>" alt="Gambar Pasien">
                        </figure>
                        <?php else: ?>
                        <figure class="image is-64x64">
                            <img src="https://via.placeholder.com/64" alt="Placeholder">
                        </figure>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item->nama_pasien); ?></td>
                    <td><?php echo e($item->jenis_kelamin); ?></td>
                    <td><?php echo e($item->alamat); ?></td>
                    <td>
                        <a href="/pasien/<?php echo e($item->id); ?>" class="button is-small is-info">
                            <span class="icon"><i class="fas fa-info-circle"></i></span>
                            <span>Baca Selengkapnya</span>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorium\resources\views/pasien/list.blade.php ENDPATH**/ ?>