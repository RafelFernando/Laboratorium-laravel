<?php $__env->startSection('judul','Pemeriksaan - '.$kategori->nama_pemeriksaan); ?>
<?php $__env->startSection('konten'); ?>

<section class="hero is-success">
    <div class="hero-body">
        <p class="title">Pemeriksaan</p>
        <p class="subtitle">Nama Pemeriksaan: <?php echo e($kategori->nama_pemeriksaan); ?></p>
    </div>
</section>

<section class="section">
    <div class="container">
        <table class="table is-fullwidth is-striped is-hoverable">
            <thead>
                <tr>
                    <th>No</th>
			<th>Id Pasien</th>
                    <th>Nama Pemeriksaan</th>
                    
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($index + 1); ?></td>
	<td><?php echo e($item->id_pasien); ?></td>
        <td><?php echo e($item->nama_pemeriksaan); ?></td>
  
        <td>
            <a href="/pemeriksaan/<?php echo e($item->id); ?>" class="button is-small is-info">
                <span class="icon"><i class="fas fa-info-circle"></i></span>
                <span>Selengkapnya</span>
            </a>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorium\resources\views/pemeriksaan/kategori.blade.php ENDPATH**/ ?>